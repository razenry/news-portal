<?php

namespace App\Filament\Resources\AspirationResource\Pages;

use App\Filament\Resources\AspirationResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateAspiration extends CreateRecord
{
    protected static string $resource = AspirationResource::class;
}
