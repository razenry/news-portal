<?php

namespace App\Filament\Resources\PpdbResource\Pages;

use App\Filament\Resources\PpdbResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePpdb extends CreateRecord
{
    protected static string $resource = PpdbResource::class;
}
