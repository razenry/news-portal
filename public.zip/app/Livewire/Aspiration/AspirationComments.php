<?php

namespace App\Livewire\Aspiration;

use Livewire\Component;

class AspirationComments extends Component
{
    public function render()
    {
        return view('livewire.aspiration.aspiration-comments');
    }
}
