<footer class="p-4 bg-white sm:p-6 dark:bg-gray-800 bottom-0 left-0 w-full">
    <div class="mx-auto max-w-screen-xl">
        <div class="md:flex md:justify-between">
            <div class="mb-6 md:mb-0">
                <a href="" class="flex items-center">
                    <img src="<?php echo e(asset($settings?->icon ? 'storage/' . $settings?->icon : 'logo.png')); ?>" class="mr-3 h-8" alt="FlowBite Logo" />
                    <span class="self-center text-2xl font-semibold whitespace-nowrap dark:text-white"><?php echo e($settings->name ?? "News Portal"); ?></span>
                </a>
            </div>
            <div class="grid grid-cols-2 gap-8 sm:gap-6 sm:grid-cols-3" id="kontak">
                <div>
                    <h2 class="mb-6 text-sm font-semibold text-gray-900 uppercase dark:text-white">Sosial Media</h2>
                    <ul class="text-gray-600 dark:text-gray-400">
                        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $socmeds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $socmed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <li class="mb-4">
                                <a target="_blank" href="<?php echo e($socmed->link); ?>"
                                    class="hover:underline"><?php echo e($socmed->name); ?></a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                            <li class="mb-4">
                                <a target="_blank" href="#" class="hover:underline">Belum ada sosial media</a>
                            </li>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </ul>
                </div>
                <div>
                    <h2 class="mb-6 text-sm font-semibold text-gray-900 uppercase dark:text-white">Kontak</h2>
                    <ul class="text-gray-600 dark:text-gray-400">
                        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <li class="mb-4">
                                <a target="_blank" href="<?php echo e($contact->link); ?>"
                                    class="hover:underline"><?php echo e($contact->name); ?></a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                            <li class="mb-4">
                                <a target="_blank" href="#" class="hover:underline">Belum ada kontak</a>
                            </li>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </ul>
                </div>
                <div>
                    <h2 class="mb-6 text-sm font-semibold text-gray-900 uppercase dark:text-white">Unit</h2>
                    <ul class="text-gray-600 dark:text-gray-400">
                        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <li class="mb-4">
                                <a target="_blank" href="<?php echo e(route('unit.show', $unit->slug)); ?>"
                                    class="hover:underline"><?php echo e($unit->name); ?></a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                            <li class="mb-4">
                                <a target="_blank" href="#" class="hover:underline">Belum ada unit</a>
                            </li>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </ul>
                </div>
            </div>
        </div>
        <hr class="my-6 border-gray-200 sm:mx-auto dark:border-gray-700 lg:my-8" />
        <div class="sm:flex sm:items-center sm:justify-between">
            <span class="text-sm text-gray-500 text-center dark:text-gray-400">© 2025 <a target="_blank" href="/"
                    class="hover:underline">NewsPortal</a>. All Rights Reserved.
            </span>
            <div class="flex mt-4 space-x-6 sm:justify-center sm:mt-0">
                <!-- icons sosial media -->
            </div>
        </div>

        <!-- Tambahan baru -->
        <div class="mt-6 text-center">
            <p class="text-sm text-gray-500 dark:text-gray-400">Developed by <span class="font-semibold">Razenry</span>
            </p>
            <p class="text-sm text-gray-500 dark:text-gray-400">A project under <span class="font-semibold">RetartedDevs
                    Startup</span></p>
        </div>
    </div>
</footer>
<?php /**PATH C:\Users\Kafka\Documents\GitHub\news-portal\resources\views/livewire/layout/footer.blade.php ENDPATH**/ ?>